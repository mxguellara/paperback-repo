import {
    MangaXStream,
    type SourceInfo
} from '@paperback/types'

export const OlympusBibliotecaInfo: SourceInfo = {
    version: '1.0.0',
    name: 'Olympus Biblioteca',
    icon: 'icon.png',
    author: 'mxguellara',
    authorWebsite: '',
    description: 'Extensión para olympusbiblioteca.com',
    websiteBaseURL: 'https://olympusbiblioteca.com',
    sourceTags: [
        {
            text: 'Español',
            type: 1
        }
    ]
}

export class OlympusBiblioteca extends MangaXStream {
    baseUrl = 'https://olympusbiblioteca.com'
    languageCode = 'es'
    hasAdvancedSearch = true
}
